// Aurex AI backend: Cloudflare Worker (free tier). Holds your Gemini key safely.
// Settings → Variables and Secrets: GEMINI_API_KEY (secret), optional MODEL, ALLOWED_ORIGIN.
export default {
  async fetch(req, env) {
    const cors = {
      "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN || "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
    };
    const out = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { ...cors, "Content-Type": "application/json" } });
    if (req.method === "OPTIONS") return new Response(null, { headers: cors });
    if (req.method !== "POST") return new Response("Aurex server is running", { headers: cors });
    try {
      const { messages, image } = await req.json();
      if (!Array.isArray(messages) || !messages.length || messages.length > 40) return out({ error: "Bad request" }, 400);
      const contents = messages.map(m => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: String(m.content).slice(0, 8000) }],
      }));
      if (image && image.data && image.data.length < 3e6)
        contents[contents.length - 1].parts.push({ inline_data: { mime_type: image.mime || "image/jpeg", data: image.data } });
      const model = env.MODEL || "gemini-2.5-flash";
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
        body: JSON.stringify({ contents }),
      });
      const j = await r.json();
      if (!r.ok) return out({ error: r.status === 429 ? "Daily free limit reached. Try later." : (j.error?.message || "AI error") }, 502);
      const text = (j.candidates?.[0]?.content?.parts || []).map(p => p.text || "").join("") || "No answer.";
      return out({ text });
    } catch (e) {
      return out({ error: "Server error" }, 500);
    }
  },
};
