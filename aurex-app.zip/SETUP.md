# Aurex AI: free setup (works from a phone browser)

## 1. Get a free AI key
Go to aistudio.google.com → Get API key → Create. Copy it.

## 2. Create the server (Cloudflare Worker, free)
1. Sign up at dash.cloudflare.com.
2. Workers & Pages → Create → Worker → Deploy, then Edit code.
3. Delete the sample, paste all of worker.js, Deploy.
4. Settings → Variables and Secrets → add secret GEMINI_API_KEY = your key.
   (If answers fail, add MODEL = a current model name from AI Studio.)
5. Copy your Worker URL (https://something.workers.dev).

## 3. Host the app (GitHub Pages, free)
1. Create a GitHub account → New repository "aurex" (public).
2. Upload everything inside the site folder (index.html, manifest.json, sw.js, both icons).
3. Settings → Pages → Branch: main → Save. Your link: https://USERNAME.github.io/aurex/

## 4. Connect them
Open your link → Settings (⚙) → paste the Worker URL.
Or edit index.html and replace PASTE_YOUR_WORKER_URL_HERE with it so every user is pre-connected.
Optional: set ALLOWED_ORIGIN in the Worker to https://USERNAME.github.io.

## 5. Install
Chrome → ⋮ → Add to Home Screen (iPhone: Safari → Share → Add to Home Screen).
Share the link with anyone.

Limits: the free tiers have daily caps, so heavy use may be rate limited.
For an APK, paste your link into pwabuilder.com.
